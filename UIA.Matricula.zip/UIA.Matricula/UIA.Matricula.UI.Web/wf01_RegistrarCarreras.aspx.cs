﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// REFERENCIA A LOS OTROS PROYECTOS:
using UIA.Matricula.BL;


public partial class wf01_RegistrarCarreras : System.Web.UI.Page
{
    // ******* OBJETOS:
    private Carrera ObjCarrera;


        protected void Page_Load(object sender, EventArgs e)
    {
        SystemInformation.ConnString_BD= ConfigurationManager.ConnectionStrings["ConStringMatriculaDB_LOCAL"].ConnectionString;

        ObjCarrera = new Carrera();

        ConfiguracionInicial();
    }


    // ********* METODOS:
    private void ConfiguracionInicial()
    {
        BuscarCarreras();
        lbl_Usuario.Text = "Adriana";
        lbl_Calidades.Text = "UIA";
    }

    //***
    private void BuscarCarreras()
    {
        if(ObjCarrera.BuscarCarreras("TablaCarreras"))
        {
            DGV_Carreras.DataSource = null;
            DGV_Carreras.DataSource = ObjCarrera.ListaDatos.Tables["TablaCarreras"];
            DGV_Carreras.DataBind();

            Lbl_Mensajes_Ayuda.Text = "Se encontraron " + DGV_Carreras.Rows.Count.ToString() + " carreras registradas.";
        }
        else
        {
            Lbl_Mensajes_Ayuda.Text = "No se hallaron Carreras.";
        }
    }

    //***
    protected void Btn_RegistrarCarrera_Click(object sender, EventArgs e)
    {

    }

    //***
    protected void Btn_LimpiarTodo_Click(object sender, EventArgs e)
    {

    }

    //***
    protected void LkB_Salir_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Response.Redirect("http://www.uia.ac.cr", true);/* tu pagina de logueo*/
    }


}