﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// REFERENCIA A LOS OTROS PROYECTOS:
using UIA.Matricula.DAL;

namespace UIA.Matricula.BL
{
    public class Carrera
    {
        // PROPIEDADES DE CLASE:
        public int IdCarrera { get; set; }
        public string CodigoCarrera { get; set; }
        public string NombreCarrera { get; set; }

        //
        private System.Data.DataSet _ListaDatos;
        public System.Data.DataSet ListaDatos  //carga de los DataSet
        {
            get { return _ListaDatos; }
        }

        //******* OBJETOS:
        private ConexionDB ConnBDMatricula;


        // CONSTRUCTOR:
        public Carrera()
        {
            ConnBDMatricula = new ConexionDB(SystemInformation.ConnString_BD);

            // INICIALIZAR PROPIEDADES:
            IdCarrera = 0;
            CodigoCarrera = string.Empty;
            NombreCarrera = string.Empty;

            //
            _ListaDatos = null;
        }


        // ******** METODOS:
        public bool BuscarCarreras(string tabla)
        {
            //Busca carreras
            string sqlcomm = string.Empty;

            sqlcomm = " SELECT IdCarrera, " +
                              "CodigoCarrera , " +
                              "NombreCarrera " +
                      " FROM Carrera ";

            if (ConnBDMatricula.ObtenerTablaDatos(sqlcomm, tabla))
            {
                _ListaDatos = ConnBDMatricula.SQLdatos;
                return true;
            }
            else
            {
                return false;
            }
        }



    }
}
