﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIA.Matricula.BL
{
    public static class SystemInformation
    {
        // string de conexion:
        public static string ConnString_BD = string.Empty;
    }
}
