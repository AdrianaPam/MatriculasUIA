﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIA.Matricula.DAL
{
    public class ConexionDB
    {


        // clase para permitir el acceso a una base de datos MS-SQL
        //**************************** PROPIEDADES ***********************************
        private SqlConnection SQLconn;        // componente que permite establecer la conexion con la B D
        private SqlDataAdapter SQLadapter;    // Conponenete que permite hacer la interfaz entra el programa y la BD
        private SqlCommand SQLcomando;        // componenete que permite enviar las instrucciones SQL a la BD
        public System.Data.DataSet SQLdatos;  // componente para almacenar datos
        public string ValorConsulta;
        private SqlParameter BDparametro;     // objeto generico para pasar parámetros a la Base de Datos

        //*********
        public ConexionDB(string ConnString) // constructor de la clase
        {   // permite inicializar todos los componentes de la clase

            //ConnString = ConfigurationManager.ConnectionStrings["ConStringSAYC"].ConnectionString + ";User ID=corLogin_app;Password=ingreso";

            SQLconn = new SqlConnection(ConnString);
            SQLcomando = new SqlCommand();
            SQLcomando.Connection = SQLconn;
            SQLadapter = new SqlDataAdapter(SQLcomando);
            SQLdatos = new System.Data.DataSet();

            ValorConsulta = "";
        }
        //**********
        public void AbrirConexion()
        {   // permite abrir una conexión a la BD
            try
            {
                SQLconn.Open();
            }
            catch (Exception ex)
            {
                ConfigurationManager.AppSettings["ErrorMessage"] = ex.ToString();// "Error de Red (DB Open)";
            }
        }
        //*********
        public void CerrarConexion()
        {   // permite cerrar una conexión a la BD
            try
            {
                SQLconn.Close();
            }
            catch
            {
                ConfigurationManager.AppSettings["ErrorMessage"] = "Error de Red (DB Close)";
            }
        }
        //**********
        public bool ObtenerTablaDatos(string SentenciaSQL, string TablaDatos)
        {   // los datos que le regresan a esta función se guardan en TablaDatos
            if (SQLdatos.Tables.Contains(TablaDatos))
            {
                SQLdatos.Tables.Remove(TablaDatos);  // quita una tabla especifica de un dataset
                //SQLdatos.Clear();                  // limpia el dataset de datos que pueda tener anteriormente -- OJO BORRA OTROS DS¡¡¡
            }

            SQLcomando.CommandText = SentenciaSQL; // indica cual sentecncia SQL se va a utilizar para enviar a la BD
            SQLadapter.SelectCommand = SQLcomando; // es una sentencia tipo SELECT para obtener datos de la BD
            AbrirConexion();                       // es aqui cuando se conecta a la base de datos

            try
            {
                // recupera los datos de la BD
                // fill toma la sentencia SQL y llena con los datos al DataSet que se llama TablaDatos
                if (SQLadapter.Fill(SQLdatos, TablaDatos) > 0)  // si fill > 0 si se encontraron datos SINO no hay datos
                {
                    CerrarConexion();
                    return true; // SI encontro datos
                }
                else
                {
                    CerrarConexion();
                    return false; // NO encontro datos
                }
            }
            catch
            {
                ConfigurationManager.AppSettings["ErrorMessage"] = "Error al ejecutar Sentencia de BD";
                CerrarConexion(); ///////////
                return false; // 
            }

        }
        //**********
        public bool ObtenerValor(string SentenciaSQL)
        {   // los datos que le regresan a esta función se guardan en ValorConsulta
            ValorConsulta = "";                    // limpia el datase de datos que pueda tener anteiormente
            SQLcomando.CommandText = SentenciaSQL; // indica cual sentecncia SQL se va a utilizar para enviar a la BD
            AbrirConexion();                       // es aqui cuando se conecta a la base de datos

            // recupera un solo dato de la BD (primer campo de la primera fila)
            try
            {
                ValorConsulta = Convert.ToString(SQLcomando.ExecuteScalar());
                if (ValorConsulta.Length > 0)  // si se encontro un dato SINO no hay dato
                {
                    CerrarConexion();
                    return true; // SI encontro dato
                }
                else
                {
                    CerrarConexion();
                    return false; // NO encontro dato
                }
            }
            catch (Exception ex)
            {
                CerrarConexion();
                //SAYC_SystemInformation.MensajeError = ex.ToString();
                return false;
            }
        }
        //**********
        public void SetParametro(string nombrePar, string ValorPar)
        {   // funcion para pasar parametros a las sentencias SQL
            if (!(SQLcomando.Parameters.Contains(nombrePar)))    // si el parametro que se quiere utilizar NO existe creado como objeto
            {
                BDparametro = new SqlParameter(nombrePar, ValorPar);   // por cada parámetro NUEVO q se pase a la BD hay que crear un objeto
                SQLcomando.Parameters.Add(BDparametro);
            }
            else // si el parametro que se quiere utilizar SI existe creado como objeto solo se le asigna el valor
            {
                SQLcomando.Parameters[nombrePar].Value = ValorPar;
            }
        }
        //**********
        public void SetParametro_Tipo_Fecha(string nombrePar, string ValorPar)
        {   // funcion para pasar parametros a las sentencias SQL con tipos DateTime
            SqlDateTime sqldatenull;
            sqldatenull = SqlDateTime.Null;

            if (!(SQLcomando.Parameters.Contains(nombrePar)))    // si el parametro que se quiere utilizar NO existe creado como objeto
            {
                SQLcomando.Parameters.Add(nombrePar, System.Data.SqlDbType.DateTime);

                if (ValorPar == "" | ValorPar == null | ValorPar == "1900-01-01 00:00:00")
                { SQLcomando.Parameters[nombrePar].Value = sqldatenull; }
                else
                { SQLcomando.Parameters[nombrePar].Value = ValorPar; }
            }
            else // si el parametro que se quiere utilizar SI existe creado como objeto solo se le asigna el valor
            {
                if (ValorPar == "")
                { SQLcomando.Parameters[nombrePar].Value = sqldatenull; }
                else
                { SQLcomando.Parameters[nombrePar].Value = ValorPar; }
            }
        }
        //*********
        public object GetDato(string NomDato, string TablaDatos)
        {   // devuelve el valor de un campo de una fila de la Base de datos
            object ValorDato;
            // SQLdatos es donde esta la informacion que se trajo de la BD
            ValorDato = SQLdatos.Tables[TablaDatos].Rows[0][NomDato];
            // de lo que se trajo de la BD. de la tabla TablaDatos, quiero que me copie el dato de la columna NomDato

            return ValorDato;
        }
        //*******
        public bool EjecutarComandoSQL(string SentenciaSQL)
        {   // ejecuta sentenciaS SQL en la Base de datos como INSERT, DELETE y UPDATE
            SQLcomando.CommandText = SentenciaSQL;

            AbrirConexion();
            //SqlTransaction myTrans = default(SqlTransaction); ////////
            try
            {
                //myTrans = SQLconn.BeginTransaction(); ////////
                //SQLcomando.Transaction = myTrans; ////////

                if (SQLcomando.ExecuteNonQuery() > 0)
                {   // si afecto mas de cero filas de la BD entonces si se ejecuto la sentencia SQL
                    //myTrans.Commit(); ////////
                    CerrarConexion();
                    return true;
                }   // si no se ejecuto la sentencia SQL devuelva FALSE
                else
                {
                    CerrarConexion();
                    return false;
                }
            }
            catch (Exception ex)
            {
                //myTrans.Rollback(); ////////
                CerrarConexion();
                //SAYC_SystemInformation.MensajeError = ex.ToString();
                return false;
            }
        }

        //****************
        public static string FechaBaseDatos()
        {   // Devuelve la fecha del Servidor de Base de Datos
            string StrSQL_Busqueda = "SELECT GETDATE();";
            DateTime FechaBD = DateTime.Parse("2015-01-01 01:01:01");
            string fecha_e = "";
            string ConexString = ConfigurationManager.ConnectionStrings["ConStringSAYC"].ConnectionString + ";User ID=corLogin_app;Password=ingreso";

            using (SqlConnection cnx = new SqlConnection(ConexString))
            {
                try
                {
                    cnx.Open();
                    SqlCommand command = new SqlCommand(StrSQL_Busqueda, cnx);
                    command.Parameters.AddWithValue("@fechaBD", FechaBD);

                    FechaBD = Convert.ToDateTime(command.ExecuteScalar());
                    fecha_e = FechaBD.ToString("yyyy-MM-dd HH:mm:ss");
                    cnx.Close(); ////////
                }
                catch (Exception e)
                {
                    try
                    {
                        cnx.Close(); ////////
                    }
                    catch
                    {
                        ConfigurationManager.AppSettings["ErrorMessage"] = "Error de Red (DB Close)";
                    }
                }
            }
            return fecha_e;
        }


    }
}
